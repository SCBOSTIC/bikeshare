import time
import pandas as pd
import numpy as np

CITY_DATA = {'chicago': 'chicago.csv', 'new york city': 'new_york_city.csv', 'washington': 'washington.csv'}


# "ask user which city they want to analyze "
# "ask the user which month(s) they want to analyze"
# "ask user which day(s) they want to analyze"

def get_filters():
    print("Hello! Are you ready to discover some exciting US Bikeshare Data? Let\'s get started !")
    print("Do us a favor and use all lower case for your input, the staff thanks  you!")
    while True:
        city = str(input( "Enter  one of the following cities..... chicago, new york city or washington:  "))
        if city.lower() == "chicago":
            print("Great choice. I love the windy city!")
        if city.lower() not in ["chicago", "new york city", "washington"]:
            print("Your entry is not a valid choice. Please make a correct choice, thank you.")
        else:
            break

    while True:
        month = str(input("Enter a month between january and june or the word 'all' for no filters:  "))

        if month.lower() not in ["all", "january", "february", "march", "april", "may", "june"]:
            print("Please enter a valid city or all.")
        else:
            break

    while True:
        day: str = str(input("Enter a day of the week or 'all' for no filters:  "))

        if day.lower() not in ["all", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]:

            print("Choose a valid day or the correct word.")

        else:
            break

    print('-' * 40)
    return city, month, day
    # Extract the start time, month and day of the week from data frame


def load_data(city, month, day):
    df = pd.read_csv(CITY_DATA[city])
    df['Start Time'] = pd.to_datetime(df['Start Time'])
    df['month'] = df['Start Time'].dt.month
    df['day_of_week'] = df['Start Time'].dt.weekday_name

    if month != 'all':
        months = ["january", "february", "march", "april", "may", "june"]
        month = months.index(month) + 1
        df = df[df['month'] == month]
    if day != 'all':
        df = df[df['day_of_week'] == day.title()]
    return df

    # determine the most popular start hour, start month,


def time_stats(df):
    print('\nCalculating The Most Frequent Times of Travel...\n')
    start_time = time.time()
    df['hour'] = df['Start Time'].dt.hour
    mode_hour = df['hour'].mode()[0]
    print("The most popular time to check out a bikeshare bike is : ", mode_hour)
    df['day'] = df['Start Time'].dt.weekday_name
    mode_day = df['day'].mode()[0]
    print("The most common day of the week to use bikeshare is:  ", mode_day)
    df['month'] = df['Start Time'].dt.month
    mode_month = df['month'].mode()[0]
    print("The most common month to use a bikeshare bike is:  ", mode_month)

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-' * 40)

    # determine the most popular start station, end station and combination


def station_stats(df):
    print('\nCalculating The Most Popular Stations and Trip...\n')
    start_time = time.time()

    y = df.groupby(["Start Station"]).size().idxmax()
    print('Most Popular Start Station is:', y)

    z = df.groupby(["End Station"]).size().idxmax()
    print('Most Popular End Station is:', z)

    x = df.groupby(["Start Station", "End Station"]).size().idxmax()
    print('Most Popular Start Station and End Station in Combination is:', x)

    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-' * 40)

    # determine the  total trip duration and the average trip duration


def trip_duration_stats(df):
    """Displays statistics on the total and average trip duration."""
    print('\nCalculating Trip Duration...\n')
    start_time = time.time()

    total_travel_time = df['Trip Duration'].sum()
    s = total_travel_time
    m = s // 60
    second = s % 60
    h = m // 60
    minute = m % 60
    day = h // 24
    hour = h % 24
    print("The Total Time is :", day, "days", hour, "hours", minute, "minutes", second, "seconds")

    total_travel_time = df['Trip Duration'].mean()
    s = total_travel_time
    m = s // 60
    second = s % 60
    h = m // 60
    minute = m % 60
    day = h // 24
    hour = h % 24
    print("The mean time is:", day, "days", hour, "hours", minute, "minutes", second, "seconds")
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-' * 40)


def user_stats(df):
    """Displays statistics on bikeshare users."""
    print('\nCalculating User Stats...\n')
    start_time = time.time()

    user_types = df['User Type'].value_counts()
    print(user_types)

    try:
        gender = df['Gender'].value_counts()
        print(gender)
        youngest = int(df['Birth Year'].max())
        print("The youngest  person was born in  ", youngest)
        oldest = int(df['Birth Year'].min())
        print("The oldest person was born in  ", oldest)
        common = df['Birth Year'].mode()[0]
        print(" The most common birth year:", common)
    except:
        print("Washington  did not provide this information")
    print("\nThis took %s seconds." % (time.time() - start_time))
    print('-' * 40)


def main():
    while True:
        city, month, day = get_filters()
        df = load_data(city, month, day)
        time_stats(df)
        station_stats(df)
        trip_duration_stats(df)
        user_stats(df)

        restart = input('\nWould you like to restart? Enter yes or no.\n')
        if restart.lower() != 'yes':
            break


if __name__ == "__main__":
    main()
